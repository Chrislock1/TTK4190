function length = path_length(p1, p2)
d_v = p2-p1;
length = norm(d_v);